namespace MyShoesAPI.Helpers
{
    public class JwtSettings
    {
        public required string Secret { get; set; }
    }
} 